import logo from './logo.svg';
import './App.css';
import RouterApp from './config/router';

function App() {
  return (
    <div className="App">
      <header className="App-header">

        <RouterApp />
        
       </header>
    </div>
  );
}

export default App;
