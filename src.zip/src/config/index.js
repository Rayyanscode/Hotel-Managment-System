import Home from '../container/home'
import About from '../container/about'
import Contact from '../container/contact'
import Error from '../container/errorpage'
import Signin from '../container/signin'
import Signup from '../container/signup'

export {Home,About,Contact,Error,Signin,Signup}