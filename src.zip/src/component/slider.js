import React from 'react';
const Slider=()=> {
  return(
    <div>
    <img src="https://miro.medium.com/max/2800/1*C_PY1_fjcKgBsbUntSwV-w.gif" width="1583px" alt="" srcset="" />
    </div>
    
  )
}
export default Slider