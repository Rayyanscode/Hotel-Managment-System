export default function Error() {
    return(
        <>
        <h1>error page</h1>
        </>
    )
    
}