export default function Contact() {
    return(
        <>
        <h1>contact page</h1>
        </>
    )
    
}